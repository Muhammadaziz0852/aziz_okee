import psycopg2


def connection():
    return psycopg2.connect(
        password='postgres',
        host='localhost',
        port='5432'

    )


def create_table_email():
    con = connection()
    cur = con.cursor()
    cur.execute('''
        create table if not exists email(
        id serial primary key,
        subject varchar(255),
        description text,
        receiver varchar(100),
        send_time timestamp default current_timestamp
        )
    ''')
    con.commit()
    con.close()

