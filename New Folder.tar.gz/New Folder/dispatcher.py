from aiogram.fsm.storage.memory import MemoryStorage
from aiogram import Dispatcher

dp = Dispatcher(storage=MemoryStorage())