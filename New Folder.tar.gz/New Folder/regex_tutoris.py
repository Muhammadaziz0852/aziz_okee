from playwright.sync_api import sync_playwright


def capture_first_post_screenshot():
    url = 'https://www.instagram.com/'
    with sync_playwright() as p:
        browser = p.firefox.launch(headless=False)
        context = browser.new_context()
        page = context.new_page()
        page.goto(url)

        # Log in to your Instagram account
        username = "evaelfiejon"
        password = "10203040"
        page.wait_for_selector("input[name=username]").fill(username)
        page.wait_for_selector("input[name=password]").fill(password)
        page.wait_for_selector("button[type=submit]").click()
        page.wait_for_timeout(7000)

        # Go to your profile page
        profile_url = f'https://www.instagram.com/{username}/'
        page.goto(profile_url)

        # Capture the screenshot of the first post
        post_selector = 'article > div:' \
                        'nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > a:nth-child(1)'
        page.wait_for_selector(post_selector).click()
        page.wait_for_timeout(3000)
        screenshot = page.screenshot(path='first_post_screenshot.png')
        browser.close()

    return screenshot


# Capture the screenshot
capture_first_post_screenshot()